function toggleTable() {
    document.getElementById("statTable").classList.toggle("hidden");
}